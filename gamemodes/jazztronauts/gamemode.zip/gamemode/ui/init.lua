include("dialog/init.lua")
include("radar/init.lua")
include("transition/init.lua")
include("propfeed/init.lua")
include("missions/init.lua")

AddCSLuaFile( "cl_init.lua")