AddCSLuaFile( "cl_init.lua")

